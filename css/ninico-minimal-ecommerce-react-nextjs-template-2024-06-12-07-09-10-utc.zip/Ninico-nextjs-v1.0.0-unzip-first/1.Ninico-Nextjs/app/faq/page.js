
import Layout from "@/components/layout/Layout"
export default function Faq() {

    return (
        <>
            <Layout headerStyle={3} footerStyle={1} breadcrumbTitle="Faq">

            </Layout>
        </>
    )
}